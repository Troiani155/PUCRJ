#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3, datetime


class Atendimento:
  def __init__(self, id, nome_cliente, tipo_pet, nome_pet, procedimento, valor_cobrado, timestamp):
    self.id = id
    self.nome_cliente = nome_cliente
    self.tipo_pet = tipo_pet
    self.nome_pet = nome_pet
    self.procedimento = procedimento
    self.valor_cobrado = valor_cobrado
    self.timestamp = timestamp

  def __repr__(self):
    return '<id {}>'.format(self.id)

  def serialize(self):
    return {
      'id': self.id,
      'nome_cliente': self.nome_cliente,
      'tipo_pet': self.tipo_pet,
      'nome_pet': self.nome_pet,
      'procedimento': self.procedimento,
      'valor_cobrado': self.valor_cobrado,
      'timestamp':self.timestamp
    }



atendimentos = [
    {
        'nome_cliente': "Mariana",
        'tipo_pet': 'cachorro',
        'nome_pet': 'bob',
        'procedimento': 'Banho',
        'valor_cobrado': 25.0,
        'timestamp': datetime.datetime.now()
    },
    {
        'nome_cliente': "Roberto",
        'tipo_pet': 'cachorro',
        'nome_pet': 'zica',
        'procedimento': 'Banho e tosa',
        'valor_cobrado': 45.0,
        'timestamp': datetime.datetime.now()
    },
    {
        'nome_cliente': "Mariana",
        'tipo_pet': 'cachorro',
        'nome_pet': 'bob',
        'procedimento': 'Banho e tosa',
        'valor_cobrado': 48.0,
        'timestamp': datetime.datetime.now()
    },
]

def connect():
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS atendimentos (id INTEGER PRIMARY KEY NOT NULL, nome_cliente TEXT, tipo_pet TEXT, nome_pet TEXT, procedimento TEXT, valor_cobrado REAL, timestamp TEXT)")
    conn.commit()
    conn.close()
    for i in atendimentos:
        at = Atendimento(0, i['nome_cliente'], i['tipo_pet'], i['nome_pet'], i['procedimento'], i['valor_cobrado'], i['timestamp'])
        insert(at)

def insert(Atendimento):
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute('''INSERT INTO atendimentos 
                (nome_cliente, tipo_pet, nome_pet, procedimento, valor_cobrado, timestamp) 
                VALUES (?,?,?,?,?,?)''', 
    (
        #Atendimento.id,
        Atendimento.nome_cliente,
        Atendimento.tipo_pet,
        Atendimento.nome_pet,
        Atendimento.procedimento,
        Atendimento.valor_cobrado,
        Atendimento.timestamp,
    ))
    conn.commit()
    conn.close()

def view():
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM atendimentos")
    rows = cur.fetchall()
    ats = []
    for i in rows:
        at = Atendimento(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
        ats.append(at)
    conn.close()
    return ats

def update(at):
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("UPDATE atendimentos SET nome_cliente=?, tipo_pet=?, nome_pet=?, procedimento=?, valor_cobrado=? WHERE id=?", 
                (
                    at.nome_cliente,
                    at.tipo_pet,
                    at.nome_pet,
                    at.procedimento,
                    at.valor_cobrado,
                    at.id,
                    ))
    conn.commit()
    conn.close()

def delete(theId):
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("DELETE FROM atendimentos WHERE id=?", (theId,))
    conn.commit()
    conn.close()

def getClient(cliente):
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM atendimentos WHERE nome_cliente = '%s' COLLATE NOCASE"%cliente)
    rows = cur.fetchall()
    ats = []
    for i in rows:
        at = Atendimento(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
        ats.append(at)
    conn.close()
    return ats

def getAtById(at_id):
    conn = sqlite3.connect('atendimentos.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM atendimentos WHERE id = '%d' "%at_id)
    rows = cur.fetchall()

    ats = []
    for i in rows:
        at = Atendimento(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
        ats.append(at)
    conn.close()
    return ats

