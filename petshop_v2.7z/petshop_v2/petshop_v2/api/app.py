#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys
import datetime
from flask import Flask, request, jsonify
import db

app = Flask(__name__)

db_sz = 0

if not os.path.isfile('atendimentos.db'):
    db.connect()

@app.route("/") 
def index():
    
    response = jsonify({'data': 'test', 'foo': 'bar'})
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response


@app.route("/list") 
def list():

    ats = db.view()
    ats_s = [s.serialize() for s in ats]
    
    response = jsonify(ats_s)
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response

@app.route("/delete/<int:at_id>", methods=['GET'])
def delete_at(at_id):
    db.delete(at_id)

    response = jsonify({'result': 'ok'})
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response

@app.route("/update_at", methods=['POST'])
def update_at():
    
    at = db.Atendimento(request.form.get('at_id'),
                        request.form.get('nome_cliente'), 
                        request.form.get('tipo_pet'), 
                        request.form.get('nome_pet'), 
                        request.form.get('proc'), 
                        request.form.get('valor'),
                        datetime.datetime.now())
    db.update(at)
    response = jsonify({'result': 'ok'})
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response

@app.route("/add_at", methods=['POST'])
def add_at():
    at = db.Atendimento(0,
                        request.form.get('nome_cliente'), 
                        request.form.get('tipo_pet'), 
                        request.form.get('nome_pet'), 
                        request.form.get('proc'), 
                        request.form.get('valor'),
                        datetime.datetime.now())
    db.insert(at)
    response = jsonify({'result': 'ok'})
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response

@app.route("/retrieve/<int:at_id>", methods=['GET'])
def retrieve(at_id):
    at = db.getAtById(at_id)
    if len(at) <= 0:
        response = jsonify({"status": "id not found"})
    else:
        response = jsonify(at[0].serialize())
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response

@app.route("/search/<client_name>", methods=['GET'])
def search(client_name):
    print("search", client_name, file=sys.stderr)
    ats = db.getClient(client_name)
    ats_s = [at.serialize() for at in ats]
    response = jsonify(ats_s)
    response.headers.add('Access-Control-Allow-Origin', '*')    
    return response


if __name__ == '__main__':
    app.run(debug=True, port=int(os.getenv('PORT', 5000)))
